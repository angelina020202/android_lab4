package com.example.recyclerview

import android.content.Context
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview.Adapter.*



data class ColorData(val colorName: String,
                     val colorVal: Int)

class Adapter(private val context: Context,
              private val list: ArrayList<ColorData>) :
    RecyclerView.Adapter<ViewHolder>() {

    class ViewHolder(view: View) :
        RecyclerView.ViewHolder(view)
    {
      private  val tView: View = view.findViewById(R.id.tView)
        private  val textView: TextView = view.findViewById(R.id.tView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context)
            .inflate(R.layout.rview_item,parent, false)
        return ViewHolder(view)
    }
    override fun getItemCount(): Int {
      return list.count()
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = list[position]
        val textView= list[position]
        val view = list[position]

    }
}
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fun samples() = arrayListOf<ColorData>(
            ColorData("WHITE", Color.WHITE),
            ColorData("BLACK", Color.BLACK),
            ColorData("Blue", Color.BLUE),
            ColorData("red", Color.RED),
            ColorData("MAGENTA", Color.MAGENTA))
     val recyclerView: RecyclerView= findViewById(R.id.rView)
     recyclerView.layoutManager = LinearLayoutManager(this)
     recyclerView.adapter = Adapter(this, samples())
    }
}
